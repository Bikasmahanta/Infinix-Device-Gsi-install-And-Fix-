# Infinix-Device-Gsi-install
Download Treble Info App 
And Check ✅ Your Device Type .

 If Your Device Support Project Treble You Can Continue...

• <a href ="/main/src/Treble_Info_5.2.3.apk" > Treble Info</a> 
<br>
•
<br>
•

<h1>Infinix Zero 5G X 6815</h1>
<b>Testing Device</b> :Infinix Zero 5G (X6815)




<br>
<img src="https://github.com/Bikasmahanta/Infinix-Device-Gsi-install-And-Fix-/raw/refs/heads/main/trebleinfoX6815.jpg" width="360" alt="Treble info X6815" />
